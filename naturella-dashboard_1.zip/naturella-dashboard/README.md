# 🌿 Naturella Live Dashboard

דשבורד לייב — Meta Ads + Zoho CRM
מתעדכן אוטומטית כל 2 דקות.

---

## 🚀 Deploy על Vercel (חינם, 10 דקות)

### שלב 1 — GitHub
1. כנס ל־ [github.com](https://github.com) → **New repository**
2. שם: `naturella-dashboard` → **Create**
3. העלה את כל הקבצים לריפו

### שלב 2 — Vercel
1. כנס ל־ [vercel.com](https://vercel.com) → **Add New Project**
2. חבר את ה-GitHub ריפו שיצרת
3. לחץ **Deploy** (Next.js מזוהה אוטומטית)

### שלב 3 — Environment Variables
ב-Vercel → Settings → Environment Variables, הוסף:

| Key | Value |
|-----|-------|
| `META_ACCESS_TOKEN` | ה-Token מ-Meta Business Suite |
| `META_AD_ACCOUNT_ID` | `act_505818635128676` |
| `ZOHO_CLIENT_ID` | מ-Zoho API Console |
| `ZOHO_CLIENT_SECRET` | מ-Zoho API Console |
| `ZOHO_REFRESH_TOKEN` | ראה הוראות למטה |
| `ZOHO_API_DOMAIN` | `https://www.zohoapis.com` |
| `NEXT_PUBLIC_REFRESH_INTERVAL` | `120` |

### שלב 4 — Redeploy
אחרי הוספת המשתנים → **Redeploy** → הדשבורד חי! 🎉

---

## 🔑 איך להשיג Zoho Refresh Token

1. כנס ל־ [api-console.zoho.com](https://api-console.zoho.com)
2. צור **Self Client**
3. הוסף Scopes: `ZohoCRM.modules.ALL,ZohoCRM.settings.ALL`
4. לחץ **Generate Code** → קבל Authorization Code
5. הפעל את הפקודה הזו (מחלף את הערכים):

```bash
curl -X POST https://accounts.zoho.com/oauth/v2/token \
  -d "grant_type=authorization_code" \
  -d "client_id=YOUR_CLIENT_ID" \
  -d "client_secret=YOUR_CLIENT_SECRET" \
  -d "redirect_uri=https://www.zohoapis.com" \
  -d "code=YOUR_AUTH_CODE"
```

6. בתשובה תקבל `refresh_token` — זה מה שצריך.

---

## 🔑 Meta Access Token

1. כנס ל־ [developers.facebook.com/tools/explorer](https://developers.facebook.com/tools/explorer)
2. בחר את ה-App שלך
3. הוסף Permissions: `ads_read`, `ads_management`
4. לחץ **Generate Access Token**
5. להמיר ל-Long Lived Token (60 יום):

```bash
curl "https://graph.facebook.com/v19.0/oauth/access_token?grant_type=fb_exchange_token&client_id=YOUR_APP_ID&client_secret=YOUR_APP_SECRET&fb_exchange_token=SHORT_TOKEN"
```

---

## 🏃 הרצה מקומית

```bash
npm install
cp .env.example .env.local
# מלא את .env.local עם הטוקנים שלך
npm run dev
# פתח http://localhost:3000
```

---

## 📊 מה הדשבורד מציג

- **לידים היום** — מ-Zoho CRM
- **עסקאות סגורות** — לפי שלב (סגור / גביה / חדש / נפל)
- **הכנסות** — סיכום שדה Amount מ-Zoho
- **הוצאה Meta** — 7 ימים אחרונים
- **CPL** — עלות לליד מ-Meta
- **ROI** — (הכנסות - הוצאה) / הוצאה
- **גרף לידים יומי** — 7 ימים
- **הוצאה לפי קמפיין**
- **לידים ועסקאות אחרונים** — real-time

> **טיפ:** כדי לראות ROI אמיתי, ודא שכל עסקה ב-Zoho מכילה ערך בשדה **Amount**.
